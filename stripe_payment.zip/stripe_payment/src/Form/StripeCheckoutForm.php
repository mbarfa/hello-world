<?php

namespace Drupal\stripe_payment\Form;

use Stripe\Charge;
use Stripe\Customer;
use Stripe\Subscription;
use Stripe\Stripe;
use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Url;

/**
 * Class StripeCheckout.
 *
 * @package Drupal\stripe_payment\Form
 */
class StripeCheckoutForm extends FormBase {

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'stripe_simple_checkout';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    $link_generator = \Drupal::service('link_generator');
   // Stripe::setApiKey("sk_test_DW923IHgXkC89gLdALaxeRuj");

   // $a = Charge::retrieve("ch_1C1AKwCfCJ8LMKkiFqJ11uW7");
   // print_r($a);
    
    $form['group1-start'] = array(
    '#markup' => '<div class="col-sm-6">',
    );

    $form['country'] = array(
    '#title' => t('* Select your Country'),
    '#type' => 'select',
    '#required' => TRUE,
    '#options' => $this->getCoutries(),
    '#empty_option' => t('Select Your Country'),
    );

    $form['practice_name'] = array(
      '#type' => 'textfield',
      '#required' => TRUE,
      '#title' => t('* Practice name'),
      '#description' => t('Practice name'),
    );
    $form['group1-sub-start'] = array(
      '#markup' => '<div class="form-item form-group col">',
    );
    $form['address_line1'] = array(
      '#type' => 'textarea',
      '#required' => TRUE,
      '#title' => t('* Practice Address Line 1'),
      '#description' => t('Practice Address Line 1'),
      '#placeholder' => t('Street address.'),
    );
    $form['address_line2'] = array(
      '#type' => 'textarea',
      '#title' => t('Practice Address Line 2'),
      '#rows' => 1,
      '#cols' => 60,
      '#description' => t('Practice Address Line 2'),
      '#placeholder' => t('Apartment, Suite, Unit, Building, Floor, etc'),
    );
    $form['address_city'] = array(
      '#type' => 'textfield',
      '#required' => TRUE,
      '#title' => t('* City'),
      '#description' => t('City'),
    );
    $form['address_state'] = array(
      '#type' => 'textfield',
      '#required' => TRUE,
      '#title' => t('* State/Province/Region'),
      '#description' => t('State/Province/Region'),
    );
    $form['address_zipcode'] = array(
      '#type' => 'textfield',
      '#required' => TRUE,
      '#title' => t('* Zip/Code'),
      '#description' => t('Zip/Code'),
    );
    $form['group1-sub-end'] = array(
      '#markup' => '</div>',
    );   
    $form['coupon_code'] = array(
      '#type' => 'textfield',
      '#title' => t('Coupon Code (if applicable)'),
      '#description' => t('Coupon Code (if applicable)'),
    ); 

    $form['group1-end'] = array(
      '#markup' => '</div>',
    );
    
    $form['group2-start'] = array(
      '#markup' => '<div class="col-sm-6">',
    );
     $form['subscriber_firstname'] = array(
      '#type' => 'textfield',
      '#required' => TRUE,
      '#title' => t('* First Name'),
      '#description' => t('First Name'),
    );    
    $form['subscriber_lastname'] = array(
      '#type' => 'textfield',
      '#required' => TRUE,
      '#title' => t('* Last Name'),
      '#description' => t('Last Name'),
    ); 
    $form['subscriber_role'] = array(
      '#type' => 'textfield',
      '#title' => t('Role in practice'),
      '#description' => t('Role in practice'),
    ); 
    $form['contact_person_heading'] = array(
      '#markup' => '<strong class="diff-subscriber">Preferred contact person<br /> (if different from above)</strong>',
    );
    $form['preferred_firstname'] = array(
      '#type' => 'textfield',
      '#title' => t('First name'),
      '#description' => t('First name'),
    );
    $form['preferred_lastname'] = array(
      '#type' => 'textfield',
      '#title' => t('Last name'),
      '#description' => t('Last name'),
    );
    $form['preferred_role'] = array(
      '#type' => 'textfield',
      '#title' => t('Role in practice'),
      '#description' => t('Role in practice'),
    );
    
  
      $form['group4-start'] = array(
        '#markup' => '<div class="subs_body_area_Code">',
      );
      
    $form['preferred_contactphone'] = array(
      '#title' => t('* Preferred Contact Phone #'),
      '#type' => 'textfield',
      '#required' => TRUE,
      '#description' => t('Preferred Contact.'),
      '#placeholder' => t('Contact No.'),
    );
    $form['area_Code'] = array(
      '#type' => 'textfield',
      '#required' => TRUE,
      '#description' => t('Area Code.'),
      '#placeholder' => t('Area code.'),
    );
      
     
    $form['group4-end'] = array(
        '#markup' => '</div>',
      );

    $form['email'] = array(
      '#type' => 'email',
      '#required' => TRUE,
      '#title' => t('* Email'),
      '#description' => t('Email address'),
    );   

    $form['amount'] = array(
      '#type' => 'hidden',
      '#title' => t('amount'),
    ); 

    $form['currency_code'] = array(
      '#type' => 'hidden',
      '#title' => t('currencyCode'),
    );

    $form['subscription'] = array(
      '#type' => 'hidden',
      '#title' => t('Subscription'),
    );

     $form['country_value'] = array(
      '#type' => 'hidden',
      '#title' => t('Country Value'),
    );

    $form['group2-end'] = array(
      '#markup' => '</div>',
    );

    $form['group3-start'] = array(
      '#markup' => '<div class="col-sm-12 subs_body">',
    );

    $form['form_footer_heading'] = array(
    '#markup' => '<div class="subs_text">' . t('SUBSCRIPTION') . '</div>',
    );

    $form['subs_tot_amt'] = array(
    '#markup' => '<div id="subs_tot_amt"></div>',
    );
   
    $form['stripe'] = [
      '#type' => 'stripe',
      '#title' => $this->t('Credit card'),
      // The selectors are gonna be looked within the enclosing form only.
      "#stripe_selectors" => [
        'practice_name' => ':input[name="practice_name"]',
        'address_line1' => ':input[name="address_line1"]',
        'address_line2' => ':input[name="address_line2"]',
        'address_city' => ':input[name="address_city"]',
        'address_state' => ':input[name="address_state"]',
        'address_zipcode' => ':input[name="address_zipcode"]',
        'coupon_code' => ':input[name="coupon_code"]',
        'subscriber_firstname' => ':input[name="subscriber_firstname"]',
        'subscriber_lastname' => ':input[name="subscriber_lastname"]',
        'subscriber_role' => ':input[name="subscriber_role"]',
        'preferred_firstname' => ':input[name="preferred_firstname"]',
        'preferred_lastname' => ':input[name="preferred_lastname"]',
        'preferred_role' => ':input[name="preferred_role"]',
        'preferred_contactphone' => ':input[name="preferred_contactphone"]',
        'email' => ':input[name="email"]',
        'country_value' => ':input[name="country_value"]',
        'subscription' => ':input[name="subscription"]',
      ],
    ];
    $form['group3-sub-start'] = array(
      '#markup' => '<div class="form-item form-group col type-checkbox">',
    );
    
    $form['form_media_player_heading'] = array(
    '#markup' => '<div class="wifi_text">' . t('You will not be billed until 30 days after your media player has been connected to your Wi-Fi.') . '</div>',
    );

    $form['terms_and_cond'] = array(
      '#type' => 'checkbox',
      '#required' => TRUE,
      '#title' => t('I accept the <a href="/terms-conditions">terms & conditions</a>'),
    );
     $form['group3-sub-end'] = array(
      '#markup' => '</div>',
    );    

    $form['submit'] = [
      '#type' => 'submit',
      '#value' => $this->t('Complete Subscription'),
      '#attributes' => array("onclick" => "jQuery(this).attr('disabled', true);")
      ];

    if ($this->checkTestStripeApiKey()) {
      $form['submit']['#value'] = $this->t('Complete Subscription');
    }   

    $form['group3-end'] = array(
      '#markup' => '</div>',
    );
    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    if ($this->checkTestStripeApiKey()) {
      // Make test charge if we have test environment and api key.
      $stripe_token = $form_state->getValue('stripe');
      $stripe_amount = $form_state->getValue('amount');
      $stripe_subscription = $form_state->getValue('subscription');
      $stripe_currency_code = $form_state->getValue('currency_code');
      $customer = $this->createCustomer($stripe_token);
      $customer_id = $customer->id;

      if(!empty($customer->id)) {
          //drupal_set_message('User created.');
          $subscription = $this->createSubscription($customer->id, $stripe_subscription);
          $charge = $this->createCharge($customer->id, $stripe_amount, $stripe_currency_code);
          //drupal_set_message('Charge status: ' . $charge->status);
      }

      if($charge->status=='succeeded') {
        drupal_set_message('Subscription Completed!');
      } 
      else {
        drupal_set_message('Subscription has not been Completed, Please contact Admin!'); 
      }
      
    }
    // Display result.
   /* foreach ($form_state->getValues() as $key => $value) {
      drupal_set_message($key . ': ' . $value);
    }*/

  }

  /**
   * Helper function for checking Stripe Api Keys.
   */
  private function checkTestStripeApiKey() {
    $status = FALSE;
    $config = \Drupal::config('stripe.settings');
    // Test Enviroment
    if ($config->get('environment') == 'test' && $config->get('apikey.test.secret')) {
      $status = TRUE;
    }
    
    return $status;
  }

  /**
   * Helper function for test charge.
   *
   * @param string $cust_id
   *   Stripe Customer Id.
   * @param int $amount
   *   Amount for charge.
   *
   * @return /Stripe/Charge
   *   Charge object.
   */
  private function createCharge($cust_id, $amount, $currency_code) {
    $config = \Drupal::config('stripe.settings');
    Stripe::setApiKey($config->get('apikey.test.secret'));
    $charge = Charge::create([
      'amount' => $amount * 100,
      'currency' => $currency_code,
      'description' => "Charge for Channeld",
      'customer' => $cust_id,
    ]);
    return $charge;
  }


    /**
   * Helper function for create user.
   *
   * @param string $stripe_token
   *   Stripe API token.
   * @return /Stripe/Customer
   *   Charge object.
   */
  private function createCustomer($token) {
    $config = \Drupal::config('stripe.settings');
    Stripe::setApiKey($config->get('apikey.test.secret'));
    $customer = Customer::create([
      'description' => "Customer for Channeld",
      'source' => $token,
    ]);
    return $customer;
  }


    /**
   * Helper function for create subscription.
   *
   * @param string $stripe_token
   *   Stripe API token.
   * @return /Stripe/Customer
   *   Charge object.
   */
  private function createSubscription($cust_id, $plan) {

    $subscription = Subscription::create(array(
      "customer" => $cust_id,
      "items" => array(
        array(
          "plan" => $plan,
        ),
      )
    ));
    return $subscription;
  }

  public function getCoutries() {

    try {
      $uri = 'http://app.channeld.com/api/practice/ValidateInvite?inviteCode';
      $response = \Drupal::httpClient()->get($uri, array('headers' => array('Accept' => 'text/plain')));
      $response_data = (string) $response->getBody();
      $data = json_decode($response_data);
      $dataPrice = $data->price;
      $coutries= '';

      foreach($dataPrice as $key => $item) {
          if($item->country=='Australia') {
            $field_data['AUS'."|".$item->monthly."|".$item->code."|".'$'."|".'aud']=$item->country;
          } 
          if($item->country=='USA') {
            $field_data['US'."|".$item->monthly."|".$item->code."|".'$'."|".'usd']='United States';
          } 
          if($item->country=='NZ') {
            $field_data[$item->country."|".$item->monthly."|".$item->code."|".'$'."|".'nzd']='New Zealand';
          } 
          if($item->country=='CA') {
            $field_data[$item->country."|".$item->monthly."|".$item->code."|".'$'."|".'cad']='Canada';
          }
          if($item->country=='UK') {
            $field_data[$item->country."|".$item->monthly."|".$item->code."|".'£'."|".'gbp']='United Kingdom';
          } 
          if($item->country=='SG') {
            $field_data[$item->country."|".$item->monthly."|".$item->code."|".'$'."|".'sgd']='Singapore';
          } 
          if($item->country=='Europe') {
            $field_data['EU'."|".$item->monthly."|".$item->code."|".'$'."|".'eur']= $item->country;
          } 
        }
        return $field_data ;
        if (empty($data)) {
          return FALSE;
        }
      }
      catch (RequestException $e) {
      return FALSE;
      }
  }


}
