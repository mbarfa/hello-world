/**
 *  @file
 * Javascript file for custom_user module.
 */
(function ($) {
  Drupal.behaviors.stripeCustom = {
  attach: function (context, settings) {  
        	var total_amt = '';
        	var subs_details = '';
        	var amount_gst = '';
        	$('#subs_tot_amt').hide();        
			$('#edit-country').on('change', function(e) {
	    	e.preventDefault();
	    	var dataCollection = $("#edit-country").val();
	    	var fields = dataCollection.split('|');
			  var country = fields[0];
        var amount = fields[1];
        var plan = fields[2];
        var currency = fields[3];
			  var currency_code = fields[4];
			if(country=='AUS') {
              //var total_amt =  amount;
              //var subs_details = '$' + amount + '=' + amount;                  
              var amount_gst = amount * .1 ;
              var total_amt = parseFloat(amount) + parseFloat(amount_gst) ;
              var subs_details = '$' + amount + '+ $' + amount_gst + '=' + '$' + parseFloat(total_amt);  
              $('#subs_tot_amt').html(subs_details + '<strong> PER MONTH (INCL GST)</strong>');
			} else {
			  var total_amt =  amount; 
			  var subs_details = currency + amount;  
			}
			$('#subs_tot_amt').html(subs_details + '<strong> PER MONTH</strong>');
			$('#subs_tot_amt').show();
            $("input[name='subscription']").val(plan);
            $("input[name='amount']").val(total_amt);
            $("input[name='currency_code']").val(currency_code);
            $("input[name='country_value']").val(country); 
		});
	   
    }
  };
})(jQuery);
